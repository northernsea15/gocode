#!/bin/sh

bindir=../bin
confdir=../conf/${subdir}
etcdir=../etc/${subdir}

WORLDID=5


BUSINESSID=1 
TIMER=100
LOG_LEVEL=1000
TBUS_KEY=31688
METABASE_KEY=22001


